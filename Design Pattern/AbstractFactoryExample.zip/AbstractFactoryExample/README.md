# Abstract Factory Example in java

This is a simple example of the Abstract Factory design pattern in java.

## UML Diagram

![UML Diagram](AbstractFactoryExample.png)

## How to run

```bash
java -jar AbstractFactoryExample.jar
```
