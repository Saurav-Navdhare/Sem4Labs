package abstract_factory_example.factory;

import abstract_factory_example.detector.Detector;
import abstract_factory_example.detector.EmailDetector;
import abstract_factory_example.reader.Reader;
import abstract_factory_example.reader.EmailReader;

public class EmailFactory implements AbstractFactory {
    public Detector createDetector() {
        return new EmailDetector();
    }

    public Reader createReader() {
        return new EmailReader();
    }
}