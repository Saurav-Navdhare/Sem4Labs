package abstract_factory_example.factory;

import abstract_factory_example.detector.Detector;
import abstract_factory_example.reader.Reader;

public interface AbstractFactory {
    Detector createDetector();

    Reader createReader();
}
