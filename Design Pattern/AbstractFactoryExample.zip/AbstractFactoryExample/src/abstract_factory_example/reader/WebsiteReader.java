package abstract_factory_example.reader;

public class WebsiteReader implements Reader {
    public WebsiteReader() {
        read();
    }

    public void read() {
        System.out.println("Website Reader Object Created");
    }
}
