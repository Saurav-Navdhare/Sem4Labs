package abstract_factory_example.reader;

public class EmailReader implements Reader {
    public EmailReader() {
        read();
    }

    public void read() {
        System.out.println("Email Reader Object Created");
    }
}
