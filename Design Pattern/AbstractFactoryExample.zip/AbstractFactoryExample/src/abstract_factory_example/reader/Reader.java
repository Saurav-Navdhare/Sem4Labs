package abstract_factory_example.reader;

public interface Reader {
    void read();
}
