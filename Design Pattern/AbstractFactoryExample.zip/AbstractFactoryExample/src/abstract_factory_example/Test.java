package abstract_factory_example;

import abstract_factory_example.factory.EmailFactory;
import abstract_factory_example.factory.WebsiteFactory;

public class Test {
    public static void main(String[] args) {
        EmailFactory emailFactory = new EmailFactory();
        emailFactory.createDetector();
        emailFactory.createReader();

        WebsiteFactory websiteFactory = new WebsiteFactory();
        websiteFactory.createDetector();
        websiteFactory.createReader();
    }
}