package abstract_factory_example.detector;

public class EmailDetector implements Detector {
    public EmailDetector() {
        detect();
    }

    public void detect() {
        System.out.println("Email Detector Object Created");
    }
}
