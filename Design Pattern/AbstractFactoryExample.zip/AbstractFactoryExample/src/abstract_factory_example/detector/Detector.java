package abstract_factory_example.detector;

public interface Detector {
    void detect();
}
