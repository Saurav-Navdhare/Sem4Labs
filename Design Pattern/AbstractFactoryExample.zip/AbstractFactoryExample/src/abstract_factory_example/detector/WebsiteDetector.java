package abstract_factory_example.detector;

public class WebsiteDetector implements Detector {
    public WebsiteDetector() {
        detect();
    }

    public void detect() {
        System.out.println("Website Detector Object Created");
    }
}
